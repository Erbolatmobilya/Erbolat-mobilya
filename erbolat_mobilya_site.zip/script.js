document.addEventListener("DOMContentLoaded", function() {
    console.log("Erbolat Mobilya sitesi yüklendi!");
});